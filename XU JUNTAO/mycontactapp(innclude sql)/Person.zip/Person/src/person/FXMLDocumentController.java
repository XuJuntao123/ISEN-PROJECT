/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

import Dialog.AlertDialog;
import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;


/**
 *
 * @author xjt
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button btn_addPerson;
    @FXML
    private Label label;
    @FXML
    private TextField txt_lastname;
    @FXML
    private TextField txt_firstname;
    @FXML
    private TextField txt_nickname;
    @FXML
    private TextField txt_phone_number;
    @FXML
    private TextField txt_address;
    @FXML
    private TextField txt_email_address;
    @FXML
    private TextField txt_birth_date;
    
    private Connection con = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;
    private ObservableList<PersonList> data;
    
    @FXML
    private TableView<PersonList> tablePerson;
    @FXML
    private TableColumn<?, ?> columnlastname;
    @FXML
    private TableColumn<?, ?> columnfirstname;
    @FXML
    private TableColumn<?, ?> columnnickname;
    @FXML
    private TableColumn<?, ?> columnphone_number;
    @FXML
    private TableColumn<?, ?> columnaddress;
    @FXML
    private TableColumn<?, ?> columnemail_address;
    @FXML
    private TableColumn<?, ?> columnbirth_date;
    @FXML
    private Label error_lastname;
    @FXML
    private Label error_firstname;
    @FXML
    private Label error_nickname;
    @FXML
    private Label error_phone_number;
    @FXML
    private Label error_address;
    @FXML
    private Label error_email_address;
    @FXML
    private Label error_birth_date;
    @FXML
    private Button btn_UpdatePerson;
    @FXML
    private Button btn_DeletePerson;
    @FXML
    private TextField txt_search;
    
    //private int idperson;
    @FXML
    private Button btnExport;
   
    
    
    @FXML
    private void handleAddPerson(ActionEvent event) throws SQLException {
//        boolean islastnameEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_lastname, error_lastname , "lastname is need");
//        boolean isfirstnameEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_firstname, error_firstname , "firstname is need");
//        boolean isnicknameEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_nickname, error_nickname , "nickname is need");
//        boolean isphone_numberEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_phone_number, error_phone_number , "phone_number is need");
//        boolean isaddressEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_address, error_address , "address is need");
//        boolean isemail_addressEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_email_address, error_email_address , "email_address is need");
//        boolean isbirth_dateEmpty = validation.TextFieldValidation.isTextFiledNotEmpty(txt_birth_date, error_birth_date , "birth_date is need");
//  
        String sql = "INSERT INTO persons(lastname,firstname,nickname,phone_number,address,email_address,birth_date) VALUES (?,?,?,?,?,?,?)";
        String lastname = txt_lastname.getText();
        String firstname = txt_firstname.getText();
        String nickname = txt_nickname.getText();
        String phone_number = txt_phone_number.getText();
        String address = txt_address.getText();
        String email_address = txt_email_address.getText();
        String birth_date = txt_birth_date.getText();
    
                
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, lastname);
            pst.setString(2, firstname);
            pst.setString(3, nickname);
            pst.setString(4, phone_number);
            pst.setString(5, address);
            pst.setString(6, email_address);
            pst.setString(7, birth_date);
            
            int i = pst.executeUpdate();
            if(i == 1){
                //System.out.println("data insert successfully");
                AlertDialog.display("information","data insert successfully");
                setCellTable();
                loadDataFromDatabase();
                clearTextField();
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            pst.close();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        con = dba.DBConnection.personConnection();
        data = FXCollections.observableArrayList();
        setCellTable();
        loadDataFromDatabase();
        setCellValueFromTableToTextField();
        searchPerson();
        
//        fileChooser=new FileChooser();
//        fileChooser.getExtensionFilters().addAll(
//                new FileChooser.ExtensionFilter("All files", ""),
//                new FileChooser.ExtensionFilter("images", "png","jpg","gif"),
//                new FileChooser.ExtensionFilter("Text File", "txt"));
        
    } 
    private void setCellTable(){
        columnlastname.setCellValueFactory(new PropertyValueFactory<>("lastname"));
        columnfirstname.setCellValueFactory(new PropertyValueFactory<>("firstname"));
        columnnickname.setCellValueFactory(new PropertyValueFactory<>("nickname"));
        columnphone_number.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        columnaddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        columnemail_address.setCellValueFactory(new PropertyValueFactory<>("email_address"));
        columnbirth_date.setCellValueFactory(new PropertyValueFactory<>("birth_date"));
        
    }
    private void loadDataFromDatabase(){
        data.clear();
        try {
            pst = con.prepareStatement("Select * from persons");
            rs = pst.executeQuery();
            while(rs.next()){
                data.add(new PersonList(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tablePerson.setItems(data);
    }
        private void setCellValueFromTableToTextField(){
        tablePerson.setOnMouseClicked(e -> {
            PersonList pl = tablePerson.getItems().get(tablePerson.getSelectionModel().getSelectedIndex());
            txt_lastname.setText(pl.getLastname());
            txt_firstname.setText(pl.getFirstname());
            txt_nickname.setText(pl.getNickname());
            txt_phone_number.setText(pl.getPhone_number());
            txt_address.setText(pl.getAddress());
            txt_email_address.setText(pl.getEmail_address());
            txt_birth_date.setText(pl.getBirth_date());
        });
    }

    @FXML
    private void handleUpdatePerson(ActionEvent event) {
        String sql = "Update persons set firstname = ? , nickname = ? , phone_number = ? , address = ? , email_address = ? , birth_date = ? where lastname = ? ";
        try {
            String lastname = txt_lastname.getText();
            String firstname = txt_firstname.getText();
            String nickname = txt_nickname.getText();
            String phone_number = txt_phone_number.getText();
            String address = txt_address.getText();
            String email_address = txt_email_address.getText();
            String birth_date = txt_birth_date.getText();
            pst = con.prepareStatement(sql);
            pst.setString(1, firstname);
            pst.setString(2, nickname);
            pst.setString(3, phone_number);
            pst.setString(4, address);
            pst.setString(5, email_address);
            pst.setString(6, birth_date);
            pst.setString(7, lastname);
            
            int i = pst.executeUpdate();
            if(i==1){
                AlertDialog.display("information", "person update successfully");
                loadDataFromDatabase();
                clearTextField();
            }

        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void clearTextField(){
            txt_lastname.clear();
            txt_firstname.clear();
            txt_nickname.clear();
            txt_phone_number.clear();
            txt_address.clear();
            txt_email_address.clear();
            txt_birth_date.clear();        
    }

    @FXML
    private void handleDeletePerson(ActionEvent event) {
        String sql = "delete from persons where lastname = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, txt_lastname.getText());
            int i = pst.executeUpdate();
            if(i==1){
                AlertDialog.display("information","person delete successfully");
                loadDataFromDatabase();
                clearTextField();
            }
        } catch (SQLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    private void searchPerson(){
  
        txt_search.setOnKeyReleased(e->{
            if(txt_search.getText().equals("")){
                loadDataFromDatabase();     
            }
            else{
            data.clear();
            String sql = "Select * from persons where lastname LIKE '%"+txt_search.getText()+"%'"
                    +"UNION Select * from persons where firstname LIKE '%"+txt_search.getText()+"%'"
                    +"UNION Select * from persons where nickname LIKE '%"+txt_search.getText()+"%'"
                    +"UNION Select * from persons where phone_number LIKE '%"+txt_search.getText()+"%'"
                    +"UNION Select * from persons where address LIKE '%"+txt_search.getText()+"%'"
                    +"UNION Select * from persons where email_address LIKE '%"+txt_search.getText()+"%'"
                    +"UNION Select * from persons where birth_date LIKE '%"+txt_search.getText()+"%'";

            try {
                pst = con.prepareStatement(sql);
                rs = pst.executeQuery();
                while(rs.next()){
                    System.out.println("+rs.getString(2)");
                    data.add(new PersonList(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));     
                }
                tablePerson.setItems(data);
            } catch (SQLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
           
        
        });
    }

//    @FXML
//    private void handleExport(ActionEvent event) {
//        
//        
//    }
//





    
}
