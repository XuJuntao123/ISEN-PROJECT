use person;
create table persons(
idperson int identity(1,1)Primary Key,
lastname VARCHAR(45) NOT NULL UNIQUE,
firstname VARCHAR(45) NOT NULL unique,
nickname VARCHAR(45) NOT NULL unique,
phone_number VARCHAR(15) NOT NULL,
address VARCHAR(200) NOT NULL,
email_address VARCHAR(150) NOT NULL,
birth_date VARCHAR(45) NOT NULL,);INSERT INTO persons(lastname,firstname,nickname,phone_number,address,email_address,birth_date) VALUES ('xu','juntao','xjt','12','10rue','isen@','19940504');Select * from persons Select * from persons Select * from persons Update persons set firstname = 'i' where  lastname ='i';delete from persons where lastname = 'g';delete from persons where firstname='12eqw2';